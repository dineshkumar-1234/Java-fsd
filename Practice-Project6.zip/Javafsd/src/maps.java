import java.util.HashMap;
import java.util.Scanner;
public class maps {
	public static void main(String[] args) {
		HashMap<Integer,Integer>hmap = new HashMap<>();
		Scanner in = new Scanner(System.in);
		for (int i=0;i<3;i++) {
	int a=in.nextInt();
	int b=in.nextInt();
	hmap.put(a,b);
	System.out.println(hmap.put(a,b));
	}
  }
}