
public class CallMethod {
	public void printMessage() {
		System.out.println("Hello from printMessage method");
		}
	
	public int add(int a, int b) {
		return a + b;
		}
	
	public static void main(String[] args) {
		CallMethod method=new CallMethod();
		
		// Calling a method with no parameters and no return value
		method.printMessage();

		// Calling a method with parameters and a return value
		int result=method.add(5,3);
		System.out.println("Result of addition:"+result);

		// Calling a static method
		staticMethod();
		
		// Calling a non-static method 
		method.printMessage();
		}
	
	// Static method
	public static void staticMethod() {
		System.out.println("This is a static method");
		}
	}

