
public class constructortypes {

	// Default constructor
	public constructortypes() {
		System.out.println("This is the default constructor.");
	}
	
	//Parameterized constructor
	public constructortypes(String message) {
		System.out.println("Parameterized constructor with message: " + message);
	}

	// Constructor overloading
	public constructortypes(int number) {
		System.out.println("Parameterized constructor with number: " + number);
	}
	// Copy constructor
	public constructortypes(constructortypes other) {
		System.out.println("Copy constructor invoked.");
		}
	public static void main(String[] args) {
		
		// Create objects using different constructors
		constructortypes defaultConstructor = new constructortypes();
		constructortypes paramConstructor = new constructortypes("Hello, Constructor!");
		constructortypes intConstructor = new constructortypes(42);
		
		// Simulate copy constructor by creating a new object based on an existing one
		constructortypes originalObject = new constructortypes("Original");
		constructortypes copyObject = new constructortypes(originalObject);
		}
	}
