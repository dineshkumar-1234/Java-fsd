public class arrays{
	public static void main(String[] args) {
		//single-dimensional array
		int a[]= {1,2,3,4};
		for(int i=0;i<4;i++) {
			System.out.println("Elements of array:"+a[i]);
}
		//multidimensional array
		int b[][] = {{10,20,30},{10,20,40}};
		for(int i=0;i<2;i++) {
			for(int j=0;j<3;j++) {
			System.out.println("Elements of array:"+b[i][j]);
		}
	}
	}
}