import java.util.regex.*;
import java.util.ArrayList;
import java.util.List;


public class RegularExpressions{
	public static void main(String[] args) {
		// Create a list of strings to search within
		List<String> stringsToSearch = new ArrayList<>();
		stringsToSearch.add("This is a sample text");
		stringsToSearch.add("Regular expressions can be powerful");
		stringsToSearch.add("Searching for patterns is fun");
		stringsToSearch.add("Java programming is amazing");
		
		// Define the pattern to search for
		String searchString = "Java";
		
		// Compile the pattern using regular expressions
		Pattern pattern = Pattern.compile(searchString);
		
		// Iterate through the list of strings and search for the pattern
		for (String inputString : stringsToSearch) {
			Matcher matcher = pattern.matcher(inputString);
			if (matcher.find()) {
				System.out.println("Found '" + searchString + "' in: " + inputString);
				}
			}
		}
}

