public class OuterClass {

private int outerField = 10;

// Inner class
public class InnerClass {

public void displayOuterField() {
System.out.println("Value of outerField:"+ outerField);
}
}

public static void main(String[] args) {
// Create an instance of the outer class
OuterClass outer = new OuterClass();

// Create an instance of the inner class
OuterClass.InnerClass inner = outer.new InnerClass();

// Call a method of the inner class to display outerField
inner.displayOuterField();
}
}