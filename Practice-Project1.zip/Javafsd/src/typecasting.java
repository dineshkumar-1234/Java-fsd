import java.util.Scanner;
public class typecasting {

	public static void main(String[] args) {
		System.out.println("Implicit TypeCasting:");
		Scanner sc=new Scanner(System.in);
		//implicit typeCasting
		System.out.println("Enter a byte value:");
		 Byte a=sc.nextByte();
		 short b=a;
		 int c=b;
		 long d=c;
		 float e=d;
		 double f=e;
		 
		 System.out.println("short value:"+b);
		 System.out.println("int value:"+c);
		 System.out.println("long value:"+d);
		 System.out.println("float value:"+e);
		 System.out.println("double value:"+f);
		
		 System.out.println();
		 
		//explicit typeCasting
		 System.out.println("Explicit TypeCasting:");
		 Scanner s=new Scanner(System.in);
		 System.out.println("Enter a double value:");
		 double i=sc.nextDouble();
		 float j=(float)i;
		 long k=(long)j;
		 int l=(int)k;
		 short m=(short)l;
		 byte n=(byte)m;
		 
		 System.out.println("float value:"+j);
		 System.out.println("long value:"+k);
		 System.out.println("int value:"+l);
		 System.out.println("short value:"+m);
		 System.out.println("byte value:"+n);
	}
}
