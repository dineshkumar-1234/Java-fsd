import java.util.ArrayList;
import java.util.List;

public class Collections{
	public static void main(String[] args){
		List<Integer> list=new ArrayList<>();
		list.add(1);
		list.add(2);
		
		if (list.size()==2){
			System.out.println("Size verification passed");
			}
		else {
			System.out.println("Size verification failed");
			}
		
		list.remove(1);
		
		if (list.size()==1) {
			System.out.println("Removal verification passed");
			}
		else{
			System.out.println("Removal verification failed");
			}
		
		int element = list.get(0);
		
		if (element == 1){
			System.out.println("Access verification passed");
			}
		else{
			System.out.println("Access verification failed");
		}
	}
}
